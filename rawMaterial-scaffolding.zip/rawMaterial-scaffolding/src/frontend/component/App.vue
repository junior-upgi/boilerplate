<template>
    <div id="app">
        <hello></hello>
    </div>
</template>

<script>
    import Hello from './Hello.vue';

    export default {
        name: 'app',
        components: {
            Hello
        }
    };

</script>
